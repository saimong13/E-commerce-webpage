<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Check if email exists
    $checkEmail = "SELECT * FROM users WHERE email='$email'";
    $resultEmail = mysqli_query($conn, $checkEmail);

    if (mysqli_num_rows($resultEmail) > 0) {
        echo "Email already registered!";
        exit;
    }

    // Check if username exists
    $checkUser = "SELECT * FROM users WHERE username='$username'";
    $resultUser = mysqli_query($conn, $checkUser);

    if (mysqli_num_rows($resultUser) > 0) {
        echo "Username already taken!";
        exit;
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $insert = "INSERT INTO users (username, email, password) 
               VALUES ('$username', '$email', '$hashedPassword')";

    if (mysqli_query($conn, $insert)) {
        echo "User registered successfully!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
