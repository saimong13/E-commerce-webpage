<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "oline_store";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Customer info
$name    = $_POST['name'];
$phone   = $_POST['phone'];
$address = $_POST['address'];

// Product info (coming from hidden inputs in your form)
$product_name  = $_POST['product_name'];
$product_price = $_POST['product_price'];
$product_size  = $_POST['product_size'];
$product_color = $_POST['product_color'];
$product_qty   = $_POST['product_qty'];
$total_price   = $product_price * $product_qty;

$stmt = $conn->prepare("INSERT INTO orders 
  (name, phone, address, product_name, product_size, product_color, quantity, total_price) 
  VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssii", $name, $phone, $address, $product_name, $product_size, $product_color, $product_qty, $total_price);
// Calculate total
$total_price = $product_price * $product_qty;

// Insert into orders table
$stmt = $conn->prepare("INSERT INTO orders 
    (name, phone, address, product_name, product_size, product_color, quantity, total_price) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssii", $name, $phone, $address, $product_name, $product_size, $product_color, $product_qty, $total_price);

if ($stmt->execute()) {
    echo "Order received successfully!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>