<?php
session_start();

if (!isset($_SESSION["username"])) {
    header("Location: login.html");
    exit;
}
?>
<html>
    <head>
  <title>Customer Dashboard</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      background: #f4f6f9;
    }
    header {
      background: #2c3e50;
      color: white;
      padding: 15px;
      text-align: center;
    }
    .container {
      display: flex;
    }
    nav {
      width: 220px;
      background: #34495e;
      color: white;
      min-height: 100vh;
      padding: 20px;
    }
    nav ul {
      list-style: none;
      padding: 0;
    }
    nav ul li {
      margin: 15px 0;
    }
    nav ul li a {
      color: white;
      text-decoration: none;
    }
    main {
      flex: 1;
      padding: 20px;
    }
    .order-status {
      margin-top: 20px;
    
    }
    .timeline {
      display: flex;
      justify-content: space-between;
      margin: 20px 0;
      position: relative;
    }
    .timeline::before {
      content: "";
      position: absolute;
      top: 50%;
      left: 0;
      right: 0;
      height: 4px;
      background: #ccc;
      z-index: 0;
    }
    .step {
      position: relative;
      text-align: center;
      flex: 1;
      z-index: 1;
    }
    .circle {
      width: 30px;
      height: 30px;
      margin: 0 auto;
      border-radius: 50%;
      background: #ccc;
      line-height: 30px;
      color: white;
      font-size: 14px;
    }
    .active .circle {
      background: #27ae60;
    }
    .step p {
      margin-top: 10px;
      font-size: 14px;
    }
    .profile-card {
  background: #fff;
  padding: 15px;
  margin-top: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

.profile-card button {
  background: #27ae60;
  color: white;
  border: none;
  padding: 8px 12px;
  border-radius: 5px;
  cursor: pointer;
}

.modal {
  display: none;
  position: fixed;
  z-index: 1000;
  left: 0; top: 0;
  width: 100%; height: 100%;
  background: rgba(0,0,0,0.6);
  justify-content: center;
  align-items: center;
}

.modal-content {
  background: #fff;
  padding: 20px;
  width: 400px;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.3);
}

.modal-content h3 {
  margin-top: 0;
  color: #27ae60;
}

.modal-content form {
  display: flex;
  flex-direction: column;
}

.modal-content input {
  margin-bottom: 10px;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.modal-content button {
  background: #27ae60;
  color: white;
  border: none;
  padding: 10px;
  border-radius: 6px;
  cursor: pointer;
}

.close {
  float: right;
  font-size: 24px;
  cursor: pointer;
  color: #888;
}
  </style>
</head>
<body>
  <header>
    <h1>Welcome  <?php echo $_SESSION["username"]; ?>!</h1>
  </header>
  <div class="container">
    <nav>
      <ul>
        <li><a href="#" onclick="openModal()">Profile</a></li>
       <li><a href="#" onclick="openOrders()">Orders</a></li>
        <li><a href="#">Wishlist</a></li>
        <li><a href="#">Rewards</a></li>
        <li><a href="#">Support</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </nav>
    <main>
      <?php
        include 'db_connect.php';
        $username = $_SESSION['username'];
        $result = $conn->query("SELECT * FROM customers WHERE username = '$username'");
        $row = $result->fetch_assoc();
        ?>
      <div class="order-status">
        <!-- Profile Section -->
        <h2>My Profile</h2>
        <div class="profile-card">
          <p><strong>Name:</strong> <?php echo $row['name']; ?></p>
          <p><strong>Email:</strong> <?php echo $row['email']; ?></p>
          <p><strong>Phone:</strong> <?php echo $row['phone']; ?></p>
          <button onclick="openModal()">Edit</button>
        </div>
        <h2>Order Tracking</h2>
        <div class="timeline">
          <div class="step active">
            <div class="circle">1</div>
            <p>Placed</p>
          </div>
          <div class="step active">
            <div class="circle">2</div>
            <p>Processing</p>
          </div>
          <div class="step">
            <div class="circle">3</div>
            <p>Shipped</p>
          </div>
          <div class="step">
            <div class="circle">4</div>
            <p>Delivered</p>
          </div>
        </div>
      </div>
    </main>
<!-- Popup Modal -->
<div id="editModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeModal()">&times;</span>
    <h3>Edit Profile</h3>
    <form method="POST" action="update_profile.php">
      <label>Name</label>
      <input type="text" name="name" value="<?php echo $_SESSION['username']; ?>">

      <label>Email</label>
      <input type="email" name="email" value="">

      <label>Phone</label>
      <input type="text" name="phone" value="">

      <button type="submit" class="save-btn">Save Changes</button>
    </form>
  </div>
</div>
<div id="ordersModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeOrders()">&times;</span>
    <h3>Order Summary</h3>

    <?php
    include 'db_connect.php';
    $username = $_SESSION['username'];
     $orderResult = $conn->query("SELECT * FROM orders");
    $orderResult = $conn->query("SELECT * FROM orders WHERE name = '$username'");
    if ($orderResult->num_rows > 0) {
      while($order = $orderResult->fetch_assoc()) {
        $status = $order['status'];
        echo "<p><strong>Status:</strong> <span style='color:" . 
        ($status === 'Cancelled' ? '#999' : '#27ae60') . ";'>$status</span></p>";
        echo "<p><strong>Order #{$order['id']}</strong><br>
              Product: {$order['product_name']} ({$order['product_size']}, {$order['product_color']})<br>
              Qty: {$order['quantity']}<br>
              Total: {$order['total_price']}<br>
              Address: {$order['address']}<br>
              Phone: {$order['phone']}<br>
              Status: Placed</p><hr>";
      }
    } else {
      echo "<p>No orders found.</p>";
    }
    ?>
  </div>
</div>
    <?php
    $orderResult = $conn->query("SELECT * FROM orders WHERE name = '$username'");
    if ($orderResult->num_rows > 0) {
    while($order = $orderResult->fetch_assoc()) {
    $status = $order['status'];
    $isActive = ($status === 'Placed');

    echo "<div style='margin-bottom:20px;'>
            <p><strong>Order #{$order['id']}</strong><br>
            Product: {$order['product_name']} ({$order['product_size']}, {$order['product_color']})<br>
            Qty: {$order['quantity']}<br>
            Total: {$order['total_price']}<br>
            Address: {$order['address']}<br>
            Phone: {$order['phone']}<br>
            Status: <span style='color:" . ($isActive ? "#27ae60" : "#999") . ";'>$status</span></p>";

    // Show cancel button only if status is Placed
    if ($isActive) {
  echo "<form method='POST' action='delete_order.php' onsubmit=\"return confirm('Are you sure you want to delete this order?');\">
          <input type='hidden' name='order_id' value='{$order['id']}'>
          <button type='submit' style='background:#e74c3c;color:white;border:none;padding:6px 12px;border-radius:4px;cursor:pointer;'>
            Cancel Order
          </button>
        </form>";
}
    echo "<hr></div>";
  }
  } else {
  echo "<p>No orders found.</p>";
  }
  ?>
    <script>
function openOrders() {
  document.getElementById("ordersModal").style.display = "flex";
}
function closeOrders() {
  document.getElementById("ordersModal").style.display = "none";
}
</script>
  <script>
  function openModal() {
    document.getElementById("editModal").style.display = "flex";
  }

  function closeModal() {
    document.getElementById("editModal").style.display = "none";
  }
</script>
</body>
</html>

