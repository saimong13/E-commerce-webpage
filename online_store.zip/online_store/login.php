<?php
session_start(); // <-- ADD THIS

include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST["username"];
    $password = $_POST["password"];

    $query = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);

        if (password_verify($password, $row["password"])) {

            // Save user information in session
            $_SESSION["username"] = $username;

            // Redirect to protected dashboard
            header("Location: dashboard.php");
            exit;

        } else {
            echo "Incorrect password!";
        }
    } else {
        echo "User not found!";
    }
}
?>
