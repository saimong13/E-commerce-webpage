document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("registerForm");

  form.addEventListener("submit", function (e) {
    const username = form.username.value.trim();
    const email = form.email.value.trim();
    const password = form.password.value.trim();

    // Basic validation
    if (username === "" || email === "" || password === "") {
      e.preventDefault();
      alert("Please fill in all fields.");
      return;
    }

    // Email format check
    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (!emailPattern.test(email)) {
      e.preventDefault();
      alert("Please enter a valid email address.");
      return;
    }

    // Password length check
    if (password.length < 6) {
      e.preventDefault();
      alert("Password must be at least 6 characters long.");
    }
  });
});