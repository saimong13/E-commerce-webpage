<?php
session_start();
include 'db_connect.php';

if (isset($_POST['order_id'])) {
    $order_id = $_POST['order_id'];
    $username = $_SESSION['username'];

    $sql = "DELETE FROM orders WHERE id = ? AND name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $order_id, $username);

    if ($stmt->execute()) {
        echo "<script>alert('Order deleted successfully!'); window.location='dashboard.php';</script>";
    } else {
        echo "Error deleting order: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>