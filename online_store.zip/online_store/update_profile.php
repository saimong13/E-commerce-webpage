<?php
session_start();
include 'db_connect.php';
$username = $_SESSION['username'];
$name  = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];

var_dump($_SESSION['username']);  // shows the session username
var_dump($_POST);                 // shows all form values sent

$sql = "UPDATE customers SET name = ?, email = ?, phone = ? WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $name, $email, $phone, $username);

if ($stmt->execute()) {
    echo "Affected rows: " . $stmt->affected_rows; // shows if update matched a row
    echo "<script>alert('Profile updated successfully!'); window.location='dashboard.php';</script>";
} else {
    echo "Error updating profile: " . $conn->error;
}

$stmt->close();
$conn->close();
?>