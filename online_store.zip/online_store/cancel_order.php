<?php
session_start();
include 'db_connect.php';

if (isset($_POST['order_id'])) {
    $order_id = $_POST['order_id'];
    $username = $_SESSION['username'];

    // Update status to Cancelled
    $sql = "UPDATE orders SET status = 'Cancelled' WHERE id = ? AND name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $order_id, $username);

    if ($stmt->execute()) {
        echo "<script>alert('Order cancelled successfully!'); window.location='dashboard.php';</script>";
    } else {
        echo "Error cancelling order: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>